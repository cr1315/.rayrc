"""Default options and configuration files"""
